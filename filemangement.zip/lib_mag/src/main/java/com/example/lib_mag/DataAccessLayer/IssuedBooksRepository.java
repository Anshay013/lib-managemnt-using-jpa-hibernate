
package com.example.lib_mag.DataAccessLayer;

import org.springframework.data.jpa.repository.JpaRepository;

public interface IssuedBooksRepository extends JpaRepository<IssuedBooks,Integer>{
    /* JPQL code if we dont want to write codes in controller class*/
}