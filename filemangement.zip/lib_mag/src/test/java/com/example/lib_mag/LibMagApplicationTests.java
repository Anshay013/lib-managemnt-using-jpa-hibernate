package com.example.lib_mag;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibMagApplicationTests {

	@Test
	void contextLoads() {
	}

}
