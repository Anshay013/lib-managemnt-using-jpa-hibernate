package com.example.lib_mag.Controller;

import com.example.lib_mag.DataAccessLayer.Book;
import com.example.lib_mag.DataAccessLayer.BookRepository;
import com.example.lib_mag.DataAccessLayer.IssuedBooksRepository;
import com.example.lib_mag.DataAccessLayer.UserRepository;
import com.example.lib_mag.Exception.BookNameEmptyException;
import com.example.lib_mag.Exception.BookNotFoundByIdException;
import com.example.lib_mag.Exception.BookNotFoundException;
import com.example.lib_mag.Utility.BookValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import javax.swing.text.html.parser.Entity;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

@RestController // applied above the class which contains rest API'S(it is an inbuilt class when contains all sorts of API)
public class BookResource {
    private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);

    @Autowired  // objects created by autowired are created by container and container decide when to do that.
    //   more likely they are objects created by spring framework so even if there is a change in class functions
    //we don't need to change our code auto_wiring will handle it.(it works for more ambiguous codes)
    BookRepository bookRepository;

    @Autowired
    UserRepository userRepository;

    @Autowired
    IssuedBooksRepository issueRepository;

    @Autowired
    BookRepository repository;
    BookValidator validator = new BookValidator(); // object made without autowired
    /*
    @GetMapping(value = "/getBooks")
    public List<Book> getAllBook(){
        return bookRepository.findAll();
        }
     */

    // Find All books
    @GetMapping("/books")
    public List<Book> findAll() { // method findAll under getAPI -->/books is called
        LOGGER.info("all books"); // LOGGER is just like System.out.println but it has types e.g info(information)
        // ,severe(error)
        List<Book> list = new ArrayList<Book>();  // ArrayList list will store all books we want.
        //list = repository.findAll();
        try {
            list = repository.findAll();  // inbuilt fun in jpaRepository interface of java.sql
            if (list.size() == 0) {
                LOGGER.severe("empty_libary"); // LOGGER helps to print anywhere whether be file or console.
                throw new BookNotFoundException(0); // if no books are available we throw our custom made exception
                // BookNotFoundException which itself is a class created in Exception package.
                // (no.) we can put any no. as "no." argument.
            }
        } catch (BookNotFoundException exc) // now to catch this custom made exception we create a class in Exception
        // package as CustomGlobalExceptionHandler
        {
            LOGGER.severe(exc.toString()); // msg displayed as an error(exc converted to a string format and printed)
            // exc is the exception.
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "No Book Found", exc); //404 NOT_FOUND.t
            // instead of changing the status code to 404 NOT_FOUND we simply changed it by throwing an exception.
        }
        return list;
    }

    @PostMapping("/books")
    //return 201 instead of 200
    @ResponseStatus(HttpStatus.CREATED)
        // always change status code from 200 ok to 201 created is post calls
        // it looks better.
    public Book newBook(@RequestBody Book newBook) { // a new book data is passed and this function adds it to DB.
        if (validator.isValid(newBook))// isValid function is called under BookValidator class where validator is its object.
            // if the function returns ture then we add that book to our DB.
            return repository.save(newBook); // we add the book directly to our DB in mysql .save() is again
        // an inbuilt declared in jpaRepository class.
        LOGGER.severe("newBook is not valid"); // no book saved because isValid fun returns false.
        // return null;  // we can return null.(no valid title).
        throw new BookNameEmptyException(); // else instead of null we can throw our own exception.

    }

    @GetMapping("/bookById")
    public Book getById(@RequestParam(value = "id") int id) {
        List<Book> books = bookRepository.findAll();
        if (books.size() != 0) {
            for (Book book : books) {
                if (book.getId() == id)
                    return book;
            }
            LOGGER.info("book with this id is not present");
        } else
            throw new BookNotFoundByIdException();
        return null;

        // instead of writing the above fun we can simply call book.Repository.findAllById() fun and proceed.
    }


    @GetMapping(value = "/searchBooksByAuthor") // we search the books by author name.
    public List<Book> searchBooksByAuthor(@RequestParam(value = "q") String author) { //q--> author's name.
        List<Book> books = bookRepository.findAll();
        ArrayList<Book> list = new ArrayList<Book>(); // it will store the book written by the given author
        for (Book book : books) { // now we scan the List "books" where all  books are stored.
            if (book.getAuthor().equals(author)) list.add(book); // if find it we add it.(jav.sql query language).
        }
        return list;
    }

    // in few above and one below fun. we are able to access the fun. of jpaRepository interface just by
    // creating an instance of either bookRepo.,UserRepo. in UserResource and IssuedRepo. in IssuedBookResource
    // this is because all these interfaces extends to jpaRepository interface and jpaRepository contains a
    // simpleJpaRepository class which has @Repository annotation i.e a bean will be created(a spring managed
    // object)of simpleJpaRepo class so the instance thus created by @Autowired is of this class. therefore we
    // are able to access the functions.

    @GetMapping(value = "/searchBooksBySubject")
    public List<Book> searchBooksBySubject(@RequestParam(value = "q") String subject) {
        List<Book> books = bookRepository.findAll();
        ArrayList<Book> list = new ArrayList<Book>();
        for (Book book : books) {
            if (book.getSubject().equals(subject)) list.add(book);
        }
        return list;
    }

    // OR instead of this function simply call-->
    /*
      public List<Book> searchBySubject(@RequestParam(value = "q") String subject){
        return getBySubject(String subject);
      }
     */
    @DeleteMapping("/deleteById")
    public boolean deleteById(@PathVariable int id) {
        List<Book> books = bookRepository.findAll();
        if (books.size() != 0) {
            bookRepository.deleteById(id); // returns void(in built function in CrudRepository interface, now
            // the same thing happens again a bean annotation is there CrudRepo. which manages bookRepository as
            // the object to call its function deleteById(id).
            LOGGER.info("id deleted if found");
            return true;
        } else
            LOGGER.severe("DB was found empty");
        return false;
    }
}

