
package com.example.lib_mag.DataAccessLayer;

import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User,Integer>{
/* JPQL code if we dont want to write codes in controller class*/
}