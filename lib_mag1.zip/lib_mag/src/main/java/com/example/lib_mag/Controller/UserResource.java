package com.example.lib_mag.Controller;

import com.example.lib_mag.DataAccessLayer.Book;
import com.example.lib_mag.DataAccessLayer.User;
import com.example.lib_mag.DataAccessLayer.UserRepository;
import com.example.lib_mag.Exception.BookNotFoundException;
import com.example.lib_mag.Exception.UserNameEmptyException;
import com.example.lib_mag.Exception.UserNotFoundException;
import com.example.lib_mag.Utility.UserValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

@RestController
public class UserResource {
    private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
    @Autowired
    private UserRepository repository;
    UserValidator validator = new UserValidator();
    // Find
    @GetMapping("/users")
    public List<User> findAll() { // method findAll under getAPI -->/books is called
        LOGGER.info("all users"); // LOGGER is just like System.out.println but it has types e.g info(information)
        // ,severe(error)
        List<User> list = new ArrayList<User>();  // ArrayList list will store all users we want.
        //list = repository.findAll();
        try {
            list = repository.findAll();
            if (list.size() == 0) {
                // to jpaRepository
                LOGGER.severe("empty_libaryofusers"); // LOGGER helps to print anywhere whether be file or console.
                throw new UserNotFoundException(0); // if no books are available we throw our custom made exception
                // UserNotFoundException which itself is a class created in Exception package.
                // (no.) we can put any no. as "no." argument.
            }
        }
        catch(UserNotFoundException exc) // now to catch this custom made exception we create a class in Exception
        // package as CustomGlobalExceptionHandler
        {
            LOGGER.severe(exc.toString()); // msg displayed as an error(exc converted to a string format and printed)
            // exc is the exception.
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "No User Found", exc); //404 NOT_FOUND.t
            // instead of changing the status code to 404 NOT_FOUND we simply changed it by throwing an exception.
        }
        return list;
    }

    @PostMapping("/users")
    //return 201 instead of 200
    @ResponseStatus(HttpStatus.CREATED)
    public User newUser(@RequestBody User newUser) {
        if(validator.isValidUser(newUser))
        return repository.save(newUser);

        LOGGER.severe("Name not valid");
         //return null; OR throw or own exception.
        throw new UserNameEmptyException();
    }

    // Find a given user
    @GetMapping("/users/{id}")
    public User findOne(@PathVariable int id){
        LOGGER.info("get_user by id" + id);
        // Optional<User> user = repository.findById(id);
        return repository.findById(id).orElseThrow(() -> new UserNotFoundException(id)); // if id is found we return the
          // user or else we throw an exception (here findById is again an inbuilt fun. of jpaRepository class)
    }
}
